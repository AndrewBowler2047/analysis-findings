"""Entry-point tests: event routing, scheduled detection, crhelper lifecycle, seeding."""

from unittest.mock import patch

from helpers import FakeCE


# =============================================================================
# Scheduled detection path
# =============================================================================
class TestScheduledHandler:
    def test_config_invalid_exits_early(self, aws, lambda_context):
        aws["ssm"].put_parameter(
            Name=aws["param_paths"]["cost"],
            Type="StringList",
            Value="80,50,100",  # not increasing
            Overwrite=True,
        )
        import lambda_function as lf

        result = lf.lambda_handler({"source": "aws.scheduler"}, lambda_context)
        assert result["status"] == "config_invalid"

    def test_successful_run_emits(self, aws, lambda_context):
        import lambda_function as lf

        ce = FakeCE({"111111111111": 90.0, "222222222222": 10.0})
        with patch.object(lf, "_ce", ce):
            result = lf.lambda_handler({"source": "aws.scheduler"}, lambda_context)
        assert result["status"] == "ok"
        assert result["active_lease_count"] == 2
        assert result["breaches_emitted"] >= 2

    def test_api_error_path(self, aws, lambda_context):
        import lambda_function as lf

        with patch.object(lf, "_ce", FakeCE(raise_error=True)):
            result = lf.lambda_handler({"source": "aws.scheduler"}, lambda_context)
        assert result["status"] == "api_error"


# =============================================================================
# Event routing
# =============================================================================
class TestEventRouting:
    def test_cfn_event_detected(self):
        import lambda_function as lf

        cfn_event = {
            "RequestType": "Create",
            "ResponseURL": "https://cfn.example/response",
            "StackId": "arn:aws:cloudformation:...",
        }
        assert lf._is_cfn_event(cfn_event) is True

    def test_scheduled_event_not_cfn(self):
        import lambda_function as lf

        assert lf._is_cfn_event({"source": "aws.scheduler"}) is False
        assert lf._is_cfn_event({}) is False


# =============================================================================
# crhelper lifecycle handlers
# =============================================================================
class TestLifecycleHandlers:
    def test_create_seeds_existing_as_EXISTED_no_events(self, aws):
        import lambda_function as lf

        # lease-dummy-0001 (acct 111…, budget 100) at 60% -> 50 seeded as EXISTED.
        with patch.object(lf, "_ce", FakeCE({"111111111111": 60.0, "222222222222": 5.0})):
            prid = lf.create({}, None)
        assert prid == "slz-lease-monitoring-resource"
        row = aws["ddb"].get_item(
            TableName=aws["state_table"], Key={"lease_id": {"S": "lease-dummy-0001"}}
        ).get("Item")
        assert row is not None
        assert row["last_check_status"]["S"] == "EXISTED"
        assert "50" in row["cost_thresholds_breached"]["NS"]

    def test_create_handles_config_error(self, aws):
        import lambda_function as lf

        aws["ssm"].put_parameter(
            Name=aws["param_paths"]["cost"],
            Type="StringList",
            Value="bad,values",
            Overwrite=True,
        )
        with patch.object(lf, "_ce", FakeCE()):
            prid = lf.create({}, None)
        assert prid == "slz-lease-monitoring-resource"
        assert lf.helper.Data.get("seeded") == 0

    def test_update_noop(self, aws):
        import lambda_function as lf

        lf.update({}, None)
        assert "message" in lf.helper.Data

    def test_delete_is_noop(self, aws):
        import lambda_function as lf

        # Seed first, then confirm delete leaves rows intact (table retained).
        with patch.object(lf, "_ce", FakeCE({"111111111111": 60.0, "222222222222": 5.0})):
            lf.create({}, None)
        lf.delete({}, None)
        assert aws["ddb"].scan(TableName=aws["state_table"])["Count"] == 2

    def test_cfn_routing_invokes_helper(self, aws, lambda_context):
        import lambda_function as lf

        cfn_event = {
            "RequestType": "Update",
            "ResponseURL": "https://cfn.example/response",
            "StackId": "s",
            "RequestId": "r",
            "LogicalResourceId": "MonitoringLifecycleResource",
        }
        with patch.object(lf.helper, "_send"):
            result = lf.lambda_handler(cfn_event, lambda_context)
        assert result is None
