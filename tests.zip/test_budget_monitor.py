"""Integration tests for BudgetMonitor using moto (DynamoDB, EventBridge) + CE stub."""

from config import MonitoringConfig
from models import LeaseRecord, StateRecord
from monitor import BudgetMonitor
from helpers import make_lease, FakeCE


def _config():
    return MonitoringConfig(
        cost_thresholds=[50, 80, 100],
        duration_thresholds=[50, 80, 100],
        retention_days=90,
        ops_emails=[],
    )


def _monitor(aws, leases, ce):
    return BudgetMonitor(
        config=_config(),
        leases=leases,
        ddb_client=aws["ddb"],
        ce_client=ce,
        events_client=aws["events"],
        state_table_name=aws["state_table"],
        event_bus_name=aws["event_bus"],
    )


def _read_row(aws, lease_id):
    resp = aws["ddb"].get_item(
        TableName=aws["state_table"], Key={"lease_id": {"S": lease_id}}
    )
    return resp.get("Item")


class TestRun:
    def test_no_leases(self, aws):
        result = _monitor(aws, [], FakeCE()).run()
        assert result == {"status": "ok", "active_lease_count": 0, "breaches_emitted": 0}

    def test_no_breaches_writes_state(self, aws):
        lease = LeaseRecord.from_dict(make_lease(account_id="111111111111", budget=1000.0))
        ce = FakeCE({"111111111111": 10.0})  # 1% of budget
        result = _monitor(aws, [lease], ce).run()
        assert result["breaches_emitted"] == 0
        row = _read_row(aws, lease.lease_id)
        assert row["last_check_status"]["S"] == "OK"
        # no breach sets written when empty
        assert "cost_thresholds_breached" not in row

    def test_cost_breach_emits_and_records(self, aws):
        lease = LeaseRecord.from_dict(make_lease(account_id="111111111111", budget=100.0))
        ce = FakeCE({"111111111111": 85.0})  # 85% -> crosses 50 and 80
        result = _monitor(aws, [lease], ce).run()
        assert result["breaches_emitted"] == 2
        row = _read_row(aws, lease.lease_id)
        assert set(row["cost_thresholds_breached"]["NS"]) == {"50", "80"}

    def test_terminal_cost_breach(self, aws):
        lease = LeaseRecord.from_dict(make_lease(account_id="111111111111", budget=100.0))
        ce = FakeCE({"111111111111": 120.0})  # 120% -> 50, 80, 100
        result = _monitor(aws, [lease], ce).run()
        assert result["breaches_emitted"] == 3
        row = _read_row(aws, lease.lease_id)
        assert set(row["cost_thresholds_breached"]["NS"]) == {"50", "80", "100"}

    def test_api_error_records_status_no_events(self, aws):
        lease = LeaseRecord.from_dict(make_lease(account_id="111111111111"))
        ce = FakeCE(raise_error=True)
        result = _monitor(aws, [lease], ce).run()
        assert result["status"] == "api_error"
        assert result["breaches_emitted"] == 0
        row = _read_row(aws, lease.lease_id)
        assert row["last_check_status"]["S"] == "API_ERROR"

    def test_idempotent_no_refire_when_already_breached(self, aws):
        lease = LeaseRecord.from_dict(make_lease(account_id="111111111111", budget=100.0))
        ce = FakeCE({"111111111111": 85.0})
        # First run: crosses 50, 80
        _monitor(aws, [lease], ce).run()
        # Second run, same spend: nothing new should fire
        result = _monitor(aws, [lease], ce).run()
        assert result["breaches_emitted"] == 0

    def test_ttl_epoch_written(self, aws):
        lease = LeaseRecord.from_dict(make_lease(account_id="111111111111"))
        ce = FakeCE({"111111111111": 10.0})
        _monitor(aws, [lease], ce).run()
        row = _read_row(aws, lease.lease_id)
        assert int(row["ttl_epoch"]["N"]) > 0


class TestStateIO:
    def test_read_state_roundtrip(self, aws):
        lease = LeaseRecord.from_dict(make_lease(account_id="111111111111", budget=100.0))
        m = _monitor(aws, [lease], FakeCE({"111111111111": 60.0}))
        m.run()  # crosses 50
        states = m._read_state([lease.lease_id])
        assert lease.lease_id in states
        assert 50 in states[lease.lease_id].cost_thresholds_breached

    def test_read_state_missing_lease(self, aws):
        m = _monitor(aws, [], FakeCE())
        assert m._read_state(["nonexistent"]) == {}

    def test_created_at_preserved_across_runs(self, aws):
        lease = LeaseRecord.from_dict(make_lease(account_id="111111111111", budget=100.0))
        ce = FakeCE({"111111111111": 60.0})
        m = _monitor(aws, [lease], ce)
        m.run()
        first = _read_row(aws, lease.lease_id)["created_at"]["S"]
        m.run()
        second = _read_row(aws, lease.lease_id)["created_at"]["S"]
        assert first == second


class TestSeedExisting:
    def test_seeds_already_crossed_as_existed(self, aws):
        lease = LeaseRecord.from_dict(make_lease(account_id="111111111111", budget=100.0))
        ce = FakeCE({"111111111111": 85.0})  # 85% -> 50,80 already crossed
        result = _monitor(aws, [lease], ce).seed_existing()
        assert result["seeded"] == 1
        row = _read_row(aws, lease.lease_id)
        assert row["last_check_status"]["S"] == "EXISTED"
        assert set(row["cost_thresholds_breached"]["NS"]) == {"50", "80"}

    def test_seed_emits_no_events(self, aws):
        # After seeding, the bus should have received nothing; we verify
        # indirectly: a subsequent run() with the SAME spend emits nothing new.
        lease = LeaseRecord.from_dict(make_lease(account_id="111111111111", budget=100.0))
        ce = FakeCE({"111111111111": 85.0})
        m = _monitor(aws, [lease], ce)
        m.seed_existing()
        result = m.run()
        assert result["breaches_emitted"] == 0

    def test_seed_no_leases(self, aws):
        assert _monitor(aws, [], FakeCE()).seed_existing() == {"status": "ok", "seeded": 0}

    def test_seed_ce_unavailable_seeds_duration_only(self, aws):
        # Lease ~ fully elapsed on duration, CE failing -> cost set empty,
        # duration set populated, still marked EXISTED.
        lease = LeaseRecord.from_dict(
            make_lease(account_id="111111111111", budget=100.0, duration=30, elapsed_days=30)
        )
        result = _monitor(aws, [lease], FakeCE(raise_error=True)).seed_existing()
        assert result["seeded"] == 1
        row = _read_row(aws, lease.lease_id)
        assert row["last_check_status"]["S"] == "EXISTED"
        assert "cost_thresholds_breached" not in row  # CE failed -> empty cost set
        assert "duration_thresholds_breached" in row  # duration computed locally
