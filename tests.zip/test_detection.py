"""Tests for detection logic and event-entry building (mostly pure Python)."""

import json

from config import MonitoringConfig
from models import LeaseRecord, StateRecord
from monitor import (
    BudgetMonitor,
    EVT_BUDGET_THRESHOLD,
    EVT_BUDGET_EXCEEDED,
    EVT_DURATION_THRESHOLD,
    EVT_DURATION_EXCEEDED,
)
from helpers import make_lease


def _monitor(leases=None):
    cfg = MonitoringConfig(
        cost_thresholds=[50, 80, 100],
        duration_thresholds=[50, 80, 100],
        retention_days=90,
        ops_emails=[],
    )
    return BudgetMonitor(
        config=cfg,
        leases=leases or [],
        ddb_client=None,
        ce_client=None,
        events_client=None,
        state_table_name="t",
        event_bus_name="b",
    )


class TestNewlyBreached:
    def test_no_breaches(self):
        m = _monitor()
        assert m._newly_breached(40, [50, 80, 100], set()) == set()

    def test_single_new(self):
        m = _monitor()
        assert m._newly_breached(85, [50, 80, 100], {50}) == {80}

    def test_multiple_new_in_one_poll(self):
        m = _monitor()
        assert m._newly_breached(102, [50, 80, 100], {50}) == {80, 100}

    def test_first_poll_empty_set(self):
        m = _monitor()
        assert m._newly_breached(60, [50, 80, 100], set()) == {50}

    def test_already_breached_not_refired(self):
        m = _monitor()
        assert m._newly_breached(87, [50, 80, 100], {50, 80}) == set()

    def test_terminal_only_new(self):
        m = _monitor()
        assert m._newly_breached(105, [50, 80, 100], {50, 80}) == {100}


class TestPct:
    def test_normal(self):
        assert _monitor()._pct(50, 100) == 50.0

    def test_zero_denominator(self):
        assert _monitor()._pct(50, 0) == 0.0


class TestBuildEventEntries:
    def test_non_terminal_cost(self):
        lease = LeaseRecord.from_dict(make_lease())
        entries = _monitor()._build_event_entries(lease, {80}, set(), spend=82.0, days=0)
        assert len(entries) == 1
        assert entries[0]["DetailType"] == EVT_BUDGET_THRESHOLD
        detail = json.loads(entries[0]["Detail"])
        assert detail["threshold_pct"] == 80
        assert detail["observed_cost_gbp"] == 82.0

    def test_terminal_cost(self):
        lease = LeaseRecord.from_dict(make_lease())
        entries = _monitor()._build_event_entries(lease, {100}, set(), spend=120.0, days=0)
        assert entries[0]["DetailType"] == EVT_BUDGET_EXCEEDED

    def test_cost_and_duration_together(self):
        lease = LeaseRecord.from_dict(make_lease())
        entries = _monitor()._build_event_entries(lease, {80, 100}, {50}, spend=120.0, days=15)
        types = [e["DetailType"] for e in entries]
        assert EVT_BUDGET_THRESHOLD in types
        assert EVT_BUDGET_EXCEEDED in types
        assert EVT_DURATION_THRESHOLD in types
        assert len(entries) == 3

    def test_terminal_duration(self):
        lease = LeaseRecord.from_dict(make_lease())
        entries = _monitor()._build_event_entries(lease, set(), {100}, spend=0, days=30)
        assert entries[0]["DetailType"] == EVT_DURATION_EXCEEDED

    def test_empty_breaches_no_entries(self):
        lease = LeaseRecord.from_dict(make_lease())
        assert _monitor()._build_event_entries(lease, set(), set(), spend=0, days=0) == []

    def test_entry_envelope_fields(self):
        lease = LeaseRecord.from_dict(make_lease(account_id="999999999999"))
        entry = _monitor()._build_event_entries(lease, {50}, set(), spend=55.0, days=0)[0]
        assert entry["Source"] == "slz.lease-monitoring"
        assert entry["EventBusName"] == "b"
        assert "999999999999" in entry["Resources"][0]


class TestModels:
    def test_lease_from_dict_and_elapsed(self):
        lease = LeaseRecord.from_dict(make_lease(start="2026-04-15T00:00:00Z"))
        assert lease.lease_id == "lease-test-1"
        assert lease.elapsed_days() >= 0

    def test_state_empty(self):
        s = StateRecord.empty("lease-x")
        assert s.cost_thresholds_breached == set()
        assert s.duration_thresholds_breached == set()
        assert s.created_at is None

    def test_state_from_item(self):
        item = {
            "lease_id": {"S": "lease-x"},
            "cost_thresholds_breached": {"NS": ["50", "80"]},
            "duration_thresholds_breached": {"NS": ["50"]},
            "created_at": {"S": "2026-05-01T00:00:00Z"},
        }
        s = StateRecord.from_item(item)
        assert s.cost_thresholds_breached == {50, 80}
        assert s.duration_thresholds_breached == {50}
        assert s.created_at == "2026-05-01T00:00:00Z"
