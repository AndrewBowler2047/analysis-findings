"""
Shared pytest fixtures: moto-backed AWS, seeded SSM config.

POWERTOOLS_TRACE_DISABLED is set at module level (before any source import)
so the Tracer never tries to load aws_xray_sdk in the test environment.

Helpers (FakeCE, make_lease, FakeLambdaContext) live in helpers.py so test
files can import them directly without the "conftest is not importable" error.
"""

import os

# Must be set before aws_lambda_powertools is imported anywhere.
os.environ.setdefault("POWERTOOLS_TRACE_DISABLED", "true")
os.environ.setdefault("POWERTOOLS_SERVICE_NAME", "slz-lease-monitoring-test")

import boto3
import pytest
from moto import mock_aws

from helpers import FakeLambdaContext

REGION = "eu-west-2"
STATE_TABLE = "slz-lease-monitoring-state-test"
EVENT_BUS = "slz-lease-events-test"

PARAM_PATHS = {
    "cost": "/slz/test/monitoring/cost_thresholds_pct",
    "duration": "/slz/test/monitoring/duration_thresholds_pct",
    "retention": "/slz/test/monitoring/state_retention_days",
    "ops_emails": "/slz/test/monitoring/ops_team_emails",
}


@pytest.fixture(autouse=True)
def aws_env(monkeypatch):
    """Set env vars the handler reads at import time."""
    monkeypatch.setenv("AWS_DEFAULT_REGION", REGION)
    monkeypatch.setenv("AWS_ACCESS_KEY_ID", "testing")
    monkeypatch.setenv("AWS_SECRET_ACCESS_KEY", "testing")
    monkeypatch.setenv("AWS_SECURITY_TOKEN", "testing")
    monkeypatch.setenv("AWS_SESSION_TOKEN", "testing")
    monkeypatch.setenv("STATE_TABLE_NAME", STATE_TABLE)
    monkeypatch.setenv("EVENT_BUS_NAME", EVENT_BUS)
    monkeypatch.setenv("EVENT_SOURCE", "slz.lease-monitoring")
    monkeypatch.setenv("PARAM_COST_THRESHOLDS", PARAM_PATHS["cost"])
    monkeypatch.setenv("PARAM_DURATION_THRESHOLDS", PARAM_PATHS["duration"])
    monkeypatch.setenv("PARAM_STATE_RETENTION_DAYS", PARAM_PATHS["retention"])
    monkeypatch.setenv("PARAM_OPS_TEAM_EMAILS", PARAM_PATHS["ops_emails"])
    monkeypatch.setenv("POWERTOOLS_TRACE_DISABLED", "true")
    monkeypatch.setenv("POWERTOOLS_SERVICE_NAME", "slz-lease-monitoring-test")


@pytest.fixture
def aws(aws_env):
    """Start moto and yield seeded clients."""
    with mock_aws():
        ddb = boto3.client("dynamodb", region_name=REGION)
        ssm = boto3.client("ssm", region_name=REGION)
        events = boto3.client("events", region_name=REGION)

        ddb.create_table(
            TableName=STATE_TABLE,
            AttributeDefinitions=[{"AttributeName": "lease_id", "AttributeType": "S"}],
            KeySchema=[{"AttributeName": "lease_id", "KeyType": "HASH"}],
            BillingMode="PAY_PER_REQUEST",
        )
        events.create_event_bus(Name=EVENT_BUS)
        ssm.put_parameter(Name=PARAM_PATHS["cost"], Type="StringList", Value="50,80,100")
        ssm.put_parameter(Name=PARAM_PATHS["duration"], Type="StringList", Value="50,80,100")
        ssm.put_parameter(Name=PARAM_PATHS["retention"], Type="String", Value="90")
        ssm.put_parameter(
            Name=PARAM_PATHS["ops_emails"], Type="StringList", Value="ops@example.com"
        )

        yield {
            "ddb": ddb,
            "ssm": ssm,
            "events": events,
            "region": REGION,
            "state_table": STATE_TABLE,
            "event_bus": EVENT_BUS,
            "param_paths": PARAM_PATHS,
        }


@pytest.fixture
def lambda_context():
    return FakeLambdaContext()
