"""
Shared test helpers: FakeCE stub, make_lease factory, FakeLambdaContext.

Kept in a plain importable module (not conftest.py) so test files can do
    from helpers import FakeCE, make_lease
without hitting the "conftest is not importable as a module" error.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone


def make_lease(
    lease_id="lease-test-1",
    account_id="111111111111",
    start=None,
    budget=100.0,
    duration=30,
    email="a@example.com",
    elapsed_days=2,
):
    """
    Build a lease dict in the lease-store shape.
    Default start = now - elapsed_days (2 days elapsed of 30 ~= 6% duration).
    """
    if start is None:
        start_dt = datetime.now(timezone.utc) - timedelta(days=elapsed_days)
        start = start_dt.strftime("%Y-%m-%dT%H:%M:%SZ")
    return {
        "lease_id": lease_id,
        "lease_account_id": account_id,
        "lease_assignee_email": email,
        "lease_start_date_time": start,
        "max_budget_value_gbp": budget,
        "lease_duration_in_days": duration,
    }


class FakeLambdaContext:
    """Minimal Lambda context so Powertools inject_lambda_context works."""

    function_name = "slz-lease-monitoring-test"
    memory_limit_in_mb = 1024
    invoked_function_arn = (
        "arn:aws:lambda:eu-west-2:123456789012:function:slz-lease-monitoring-test"
    )
    aws_request_id = "test-request-id"


class FakeCE:
    """Stub Cost Explorer client (moto's CE support is limited)."""

    def __init__(self, account_costs: dict[str, float] | None = None, raise_error=False):
        self._costs = account_costs or {}
        self._raise = raise_error

    def get_cost_and_usage(self, **kwargs):
        if self._raise:
            from botocore.exceptions import ClientError
            raise ClientError(
                {"Error": {"Code": "ThrottlingException", "Message": "rate exceeded"}},
                "GetCostAndUsage",
            )
        accounts = kwargs["Filter"]["Dimensions"]["Values"]
        groups = [
            {
                "Keys": [acct],
                "Metrics": {
                    "UnblendedCost": {
                        "Amount": str(self._costs.get(acct, 0.0)),
                        "Unit": "GBP",
                    }
                },
            }
            for acct in accounts
        ]
        return {"ResultsByTime": [{"Groups": groups}]}
