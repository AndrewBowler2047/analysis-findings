"""Tests for ConfigLoader parsing and validation (pure Python, no AWS)."""

import pytest

from config import ConfigLoader, ConfigurationError, MonitoringConfig


class TestParseThresholds:
    def test_valid_default(self):
        assert ConfigLoader._parse_thresholds("50,80,100") == [50, 80, 100]

    def test_valid_with_spaces(self):
        assert ConfigLoader._parse_thresholds(" 50 , 80 , 100 ") == [50, 80, 100]

    def test_single_terminal_only(self):
        assert ConfigLoader._parse_thresholds("100") == [100]

    def test_empty_raises(self):
        with pytest.raises(ConfigurationError, match="empty"):
            ConfigLoader._parse_thresholds("")

    def test_missing_terminal_raises(self):
        with pytest.raises(ConfigurationError, match="terminal value 100"):
            ConfigLoader._parse_thresholds("50,80")

    def test_non_integer_raises(self):
        with pytest.raises(ConfigurationError, match="non-integer"):
            ConfigLoader._parse_thresholds("50,abc,100")

    def test_not_increasing_raises(self):
        with pytest.raises(ConfigurationError, match="strictly increasing"):
            ConfigLoader._parse_thresholds("80,50,100")

    def test_duplicates_raise(self):
        with pytest.raises(ConfigurationError, match="strictly increasing"):
            ConfigLoader._parse_thresholds("50,50,100")

    def test_out_of_range_high_raises(self):
        with pytest.raises(ConfigurationError, match="within 1..100"):
            ConfigLoader._parse_thresholds("50,80,150")

    def test_out_of_range_low_raises(self):
        with pytest.raises(ConfigurationError, match="within 1..100"):
            ConfigLoader._parse_thresholds("0,80,100")


class TestParseRetention:
    def test_valid(self):
        assert ConfigLoader._parse_retention("90") == 90

    def test_zero_raises(self):
        with pytest.raises(ConfigurationError):
            ConfigLoader._parse_retention("0")

    def test_non_numeric_raises(self):
        with pytest.raises(ConfigurationError):
            ConfigLoader._parse_retention("ninety")


class TestMonitoringConfig:
    def test_terminals_are_max(self):
        cfg = MonitoringConfig(
            cost_thresholds=[50, 80, 100],
            duration_thresholds=[25, 100],
            retention_days=90,
            ops_emails=[],
        )
        assert cfg.cost_terminal == 100
        assert cfg.duration_terminal == 100


class TestLoad:
    def test_load_from_ssm(self, aws):
        loader = ConfigLoader(aws["ssm"], aws["param_paths"])
        cfg = loader.load()
        assert cfg.cost_thresholds == [50, 80, 100]
        assert cfg.duration_thresholds == [50, 80, 100]
        assert cfg.retention_days == 90
        assert cfg.ops_emails == ["ops@example.com"]

    def test_load_invalid_threshold_raises(self, aws):
        aws["ssm"].put_parameter(
            Name=aws["param_paths"]["cost"],
            Type="StringList",
            Value="80,50,100",
            Overwrite=True,
        )
        loader = ConfigLoader(aws["ssm"], aws["param_paths"])
        with pytest.raises(ConfigurationError):
            loader.load()
